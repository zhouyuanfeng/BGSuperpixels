function [ maxk ] = findMaxgradien( seed_gradient )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
nseeds=size(seed_gradient,2);
maxg=seed_gradient(1);
maxk=1; 
for i=1:nseeds
    t=seed_gradient(i);
    if(seed_gradient(1,i)>maxg)
        maxg=seed_gradient(1,i);
        maxk=i;
    end
end
end

