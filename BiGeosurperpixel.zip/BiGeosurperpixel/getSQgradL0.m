function [ num ] = getSQgradL0( imggrad,curseed,interval,threshold )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
height=size(imggrad,1);
num=0;
width=size(imggrad,2);
 x1=fix(max(1,(curseed(2,1)-sqrt(3.0)/2*interval)));   
 x2=fix(min(double(curseed(2,1)+sqrt(3.0)/2*interval),(width)));
 y1=fix(max(1,(curseed(1,1)-interval)));
 y2=fix(min(double(curseed(1,1)+interval),(height)));
for i=y1:y2
     for j=x1:x2
         if(imggrad(i,j)>threshold)
             num=num+1;
         end
     end
end
end

