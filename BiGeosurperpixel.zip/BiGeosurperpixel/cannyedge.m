function [e,mag] = cannyedge(image,thre)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
if ~(nargin>=1)
   error('Not Enough Input!');
else
	A=image;
end

if isa(A, 'uint8')  
   A = im2double(A);
end
PercentOfPixelsNotEdges = .7; % Used for selecting thresholds
ThresholdRatio = .4;          % Low thresh is this fraction of the high.

m = size(A,1);
n = size(A,2);
rr = 2:m-1; cc=2:n-1;

% The output edge map:
e = repmat(logical(uint8(0)), m, n);

%Filtro segundo o eixo X
Nx1=10;Sigmax1=1;Nx2=10;Sigmax2=1;Theta1=pi/2;
%Filtro segundo o eixo Y
Ny1=10;Sigmay1=1;Ny2=10;Sigmay2=1;Theta2=0;

% Detec��o de orlas segundo a direc��o do eixo dos X's
filterx=d2dgauss(Nx1,Sigmax1,Nx2,Sigmax2,Theta1);
ax= conv2(A,filterx,'same');

% Detec��o de orlas segundo a direc��o do eixo dos Y's
filtery=d2dgauss(Ny1,Sigmay1,Ny2,Sigmay2,Theta2);
ay=conv2(A,filtery,'same'); 

%Norma do Gradiente 
mag = sqrt((ax.*ax) + (ay.*ay));
magmax = max(mag(:));
if magmax>0
   mag = mag / magmax;   % normalize
end
  
% Select the thresholds                                                                      
if nargin==2
   thresh=thre;
else
   thresh=[];
end;
%thresh=[0.03,0.1];
if isempty(thresh) 
   [counts,x]=imhist(mag, 64);
   highThresh = min(find(cumsum(counts) > PercentOfPixelsNotEdges*m*n)) / 64;
   lowThresh = ThresholdRatio*highThresh;
   thresh = [lowThresh highThresh];
elseif length(thresh)==1
   highThresh = thresh;
   if thresh>=1
   	error('The threshold must be less than 1.');
   end
   lowThresh = ThresholdRatio*thresh;
   thresh = [lowThresh highThresh];
elseif length(thresh)==2
   lowThresh = thresh(1);
   highThresh = thresh(2);
   if (lowThresh >= highThresh) | (highThresh >= 1)
      error('Thresh must be [low high], where low < high < 1.');
   end
end

% The next step is to do the non-maximum supression.  
% We will accrue indices which specify ON pixels in strong edgemap
% The array e will become the weak edge map.
idxStrong = [];  
for dir = 1:4
	idxLocalMax = cannyFindLocalMaxima(dir,ax,ay,mag);
	idxWeak = idxLocalMax(mag(idxLocalMax) > lowThresh);
	e(idxWeak)=1; 
   idxStrong = [idxStrong; idxWeak(mag(idxWeak) > highThresh)];
end
   
rstrong = rem(idxStrong-1, m)+1;
cstrong = floor((idxStrong-1)/m)+1; 
e = bwselect(e, cstrong, rstrong, 8);
e = bwmorph(e, 'thin', 1);  % Thin double (or triple) pixel wide contours
%imshow(e)
end

