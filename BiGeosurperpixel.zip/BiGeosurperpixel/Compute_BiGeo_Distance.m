function [D,S,Q] = Compute_BiGeo_Distance(W, start_points,Img,seed_color, std,lim,alph,options)

% perform_fast_marching - launch the Fast Marching algorithm, in 2D or 3D.
%
%   [D,S,Q] = perform_fast_marching(W, start_points, options)
%
%   W is an (n,n) (for 2D, d=2) or (n,n,n) (for 3D, d=3) 
%       weight matrix. The geodesics will follow regions where W is large.
%       W must be > 0.
%   'start_points' is a d x k array, start_points(:,i) is the ith starting point .
%
%   D is the distance function to the set of starting points.
%   S is the final state of the points : -1 for dead (ie the distance
%       has been computed), 0 for open (ie the distance is only a temporary
%       value), 1 for far (ie point not already computed). Distance function
%       for far points is Inf.
%   Q is the index of the closest point. Q is set to 0 for far points.
%       Q provide a Voronoi decomposition of the domain. 

end_points=[];
values=[];
L=[];
H=[];
nb_iter_max=Inf;
d = ndims(W);
if d~=2 && d~=3
    error('Works only in 2D and 3D.');
end
if size(start_points,1)~=d
    error('start_points should be (d,k) dimensional with k=2 or 3.');
end

L(L==-Inf)=-1e9;
L(L==Inf)=1e9;
nb_iter_max = min(nb_iter_max, 1.2*max(size(W))^d);
%nb_iter_max=size( start_points,2)*maxite;
% use fast C-coded version if possible
if d==2     
    if exist('compute_bilgeo_diatance')~=0  
        [D,S,Q] = compute_bilgeo_diatance(W,start_points-1,Img,seed_color,std,lim,alph,end_points-1,nb_iter_max, H, L, values);
    end
end
Q = Q+1;

% replace C 'Inf' value (1e9) by Matlab Inf value.
D(D>1e14) = Inf;