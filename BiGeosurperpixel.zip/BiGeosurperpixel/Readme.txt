This software is the matlab re-implementation version of the algorithm in the following paper. Run the BiGeoSuperpixels.m to execute the algorithm. Please cite our paper when you publish new relevant papers. Thanks.


 ******************** Yuanfeng Zhou, Xiao Pan, Wenping Wang, Yilong Yin, Caiming Zhang, "Superpixels by Bilateral Geodesic Distance", IEEE Transactions on Circuits and Systems for Video Technology, 27(11): 2281-2293 (2017). copyright@sdu*********************************************************************************