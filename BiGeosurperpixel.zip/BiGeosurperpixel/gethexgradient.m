function [ NumBgra ] = gethexgradient( imggrad,curseed,interval,avgrad)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

h=size(imggrad,1);
w=size(imggrad,2);
x1=fix(max(1,(curseed(2,1)-sqrt(3.0)/2*interval)));   
x2=fix(min(double(curseed(2,1)+sqrt(3.0)/2*interval),(w)));
y1=fix(max(1,(curseed(1,1)-interval)));
y2=fix(min(double(curseed(1,1)+interval),(h)));
NumBgra=0;
 for i=y1:y2
     for j=x1:x2
        if(imggrad(i,j)>avgrad)
            NumBgra=NumBgra+1;
        end
     end
 end
end

