#include "mex.h"

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
 {
        double *Edis,*q1,*img;
        double *seed_pos;
        int iWidth, iHeight;
        iHeight = mxGetM(prhs[0]);
        iWidth = mxGetN(prhs[0]);
     //   plhs[0] = mxCreateDoubleMatrix(iHeight,iWidth, mxREAL);
        img = mxGetPr(prhs[0]);
        q1 = mxGetPr(prhs[1]);
        seed_pos=mxGetPr(prhs[2]);
       int  nseeds=mxGetN(prhs[2]);
         Edis=mxGetPr(plhs[0]);
        int size=iHeight*iWidth;
     
      /*    for(int i=0;i<iWidth;i++)
          {
             for(int j=0;j<iHeight;j++)
             {
                  double dis;
                  dis=0.0;
            
                  
                   int x,y;
                   int num=(int)q1[i*iHeight+j];
                   x=seed_pos[(num-1)*2]-1;
                   y=seed_pos[(num-1)*2+1]-1;
                   dis=(i-x)*(i-x)+(j-y)*(j-y);
                   
     
               Edis[i*iHeight+j]=dis;
             }
           }*/
     
        
       plhs[0]= mxCreateDoubleMatrix(2,nseeds, mxREAL);
       double *seeds=mxGetPr(plhs[0]);
       for(int i=0;i<nseeds;i++)
       {
           seeds[i*2]=seed_pos[i*2];
           seeds[i*2+1]=seed_pos[i*2+1];
       }
        
   }
