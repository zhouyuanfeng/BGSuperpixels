function [A,avC,avCall] = getSupersizeA(img,W,Q,nums)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
A=zeros(1,nums);
c=size(W);
h=c(1);
w=c(2);
sumA=0.0;
avC=zeros(3,nums);
avCall=0;;
numP=ones(1,nums);
for i=1:h
    for j=1:w
        A(1,Q(i,j))=A(1,Q(i,j))+W(i,j);
        sumA=sumA+W(i,j);
        avC(1,Q(i,j))=avC(1,Q(i,j))+img(i,j,1);
    %    avC(2,Q(i,j))=avC(2,Q(i,j))+img(i,j,2);
    %    avC(3,Q(i,j))=avC(3,Q(i,j))+img(i,j,3);
        avCall=avCall+img(i,j,1);
        numP(1,Q(i,j))=numP(1,Q(i,j))+1;
    end
end
numP=numP-1;

for i=1:nums
    if(numP(1,i)>0)
avC(1,i)=avC(1,i)./numP(1,i);
avCall=avCall/(h*w);
%avC(2,i)=avC(2,i)./numP(1,i);
%avC(3,i)=avC(3,i)./numP(1,i);
    end
end
end

