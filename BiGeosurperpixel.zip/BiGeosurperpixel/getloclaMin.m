function [ seed_pos ] = getloclaMin( seed_pos,seed_interval,imgrad )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
nseeds=size(seed_pos,2);
h=size(imgrad,1);
w=size(imgrad,2);
haveseed=zeros(h,w);
for i=1:nseeds
    y1=round(max(1,seed_pos(1,i)-fix(seed_interval(i)/3)));
    y2=round(min(h,seed_pos(1,i)+fix(seed_interval(i)/3)));
    x1=round(max(1,seed_pos(2,i)-fix(seed_interval(i)/3)));
    x2=round(min(w,seed_pos(2,i)+fix(seed_interval(i)/3)));
   
    y=seed_pos(1,i);
    x=seed_pos(2,i);
    igrad=imgrad(y,x);
    for j=y1:y2
        for k=x1:x2
            curseeds(1,1)=j;
            curseeds(2,1)=k;
            if(imgrad(j,k)<igrad&&Whehaveseed(curseeds,haveseed)==0)
                igrad=imgrad(j,k);
                y=j;
                x=k;
            end
        end
    end
    haveseed(y,x)=1;
    seed_pos(1,i)=y;
    seed_pos(2,i)=x;
end
end

