function [ seed_color ] =get_seedhexavColor( seed_pos,N,seed_intv )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
nseeds=size(seed_pos,2);
seed_color=zeros(3,nseeds);
h=size(N,1);
w=size(N,2);
for i=1:nseeds
    intv=seed_intv(1,i);
    intv=round((intv*sqrt(3)/2)/2);
    count=0;
%     if(i==474)
%         intv=3;
%     end
    for ii=-intv:1:intv
        for jj=-intv:1:intv
            yy=seed_pos(1,i)+ii;
            xx=seed_pos(2,i)+jj; 
            if(yy>=1&&yy<=h&&xx>=1&&xx<=w)
                seed_color(1,i)=seed_color(1,i)+N(yy,xx,1);
                seed_color(2,i)=seed_color(2,i)+N(yy,xx,2);
                seed_color(3,i)=seed_color(3,i)+N(yy,xx,3);
                count=count+1;
            end
        end
    end
    seed_color(1,i)=seed_color(1,i)/count;
    seed_color(2,i)=seed_color(2,i)/count;
    seed_color(3,i)=seed_color(3,i)/count;
end

end

