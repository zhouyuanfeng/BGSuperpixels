segpath='E:\depth\RGBDsuperpixel-meshupdatemesh\RandomResult\segResult1201';
numS=[500 800 1100 1400 1700 2000];
segfile=dir([sepath '/*.txt']);
numSeg=numel(segfile);
Notseg=[];
for i=1:1449
    fid=1000000+i;
    sfid=num2str(fid);
    sname=sfid(2:end);
    for kk=1:6
      segf=strcat(sname,'_',num2str(numS(kk)));
      isseg=0;
      for kkk=1:numSeg
          if( strfind(segfile(kkk).name, segf)>0)
                isseg=1;
                break;  
          end 
      end
      if(isseg==0)
          nots(1,1)=i;
          nots(2,1)=kkk;
          Notseg=[Notseg nots];
      end
    end
end