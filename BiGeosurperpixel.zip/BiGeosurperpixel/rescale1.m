function [ y ] = rescale1( x,a,b )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
h=size(x,1);
w=size(x,2);
y=zeros(h,w);

for i=1:h
    for j=1:w
     
        if(x(i,j)>b)
            y(i,j)=1;
        end
        if(x(i,j)<a)
            y(i,j)=0;
        end
        if(x(i,j)<b&&x(i,j)>a)
            y(i,j)=(x(i,j)-a)/(b-a);
        end
    end
end
end

