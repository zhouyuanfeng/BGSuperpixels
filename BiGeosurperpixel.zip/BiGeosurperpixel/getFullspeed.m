function [ speed_l ] = getFullspeed( speed_grad,Al,avA )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes 
c=size(Al);
h=c(1);
w=c(2);
sig=avA;
speel_l=ones(h,w);
for i=1:h
    for j=1:w
        d=max(0,(Al(i,j)-avA));
        gas=(1/sqrt(2*pi))*exp(-d*d/(2*sig*sig));
        speed_l(i,j)=speed_grad(i,j)*gas;
    end
end

end

