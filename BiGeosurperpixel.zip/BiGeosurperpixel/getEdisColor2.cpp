#include "mex.h"
#include "math.h"
void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
{
    double *seeds_color;
   seeds_color=mxGetPr(prhs[0]);
   double *q;
   q=mxGetPr(prhs[1]);
   int iWidth, iHeight;
   iHeight = mxGetM(prhs[1]);
   iWidth = mxGetN(prhs[1]);
   double *img;
   img=mxGetPr(prhs[2]);
   double *Edis;
   plhs[0]= mxCreateDoubleMatrix(iHeight,iWidth, mxREAL);
   Edis=mxGetPr(plhs[0]);
   int num;
   double r,g,b;
   double dis;
   int imgsize=iWidth*iHeight;
   for(int i=0;i<iWidth;i++)
   {
       for(int j=0;j<iHeight;j++)
       {
           num=(int)q[i*iHeight+j];
           num=num-1;
           r=seeds_color[num*3];
           g=seeds_color[num*3+1];
           b=seeds_color[num*3+2];
           double d1=(img[i*iHeight+j]-r)*(img[i*iHeight+j]-r);
           double d2=(img[i*iHeight+j+imgsize]-g)*(img[i*iHeight+j+imgsize]-g);
           double d3=(img[i*iHeight+j+imgsize*2]-b)*(img[i*iHeight+j+imgsize*2]-b);
           //+(img[i*iHeight+j+imgsize]-g)*(img[i*iHeight+j+imgsize]-g)+(img[i*iHeight+j+imgsize*2]-b)*(img[i*iHeight+j+imgsize*2]-b);
         // dis=1;
           dis=d1+d2+d3;
           Edis[i*iHeight+j]=sqrt(dis);
       }
   }
   
}
