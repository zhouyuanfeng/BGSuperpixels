function [ isseed ] = Whehaveseed( curseed,haseed)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
h=size(haseed,1);
w=size(haseed,2);
x=curseed(1,1);
y=curseed(2,1);
x1=max(1,curseed(2,1)-1);
x2=min(curseed(2,1)+1,w);
y1=max(1,curseed(1,1)-1);
y2=min(h,curseed(1,1)+1);
isseed=0;
for i=y1:y2
    for j=x1:x2
        if(haseed(i,j)==1)
            isseed=1;
     
            break;
        end
    end
end

end

