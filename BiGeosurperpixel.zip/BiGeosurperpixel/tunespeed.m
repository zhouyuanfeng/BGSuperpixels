function [ grad_speed1 ] = tunespeed( grad_speed )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
grad_speed1=grad_speed;
h=size(grad_speed,1);
w=size(grad_speed,2);
for i=1:h
    grad_speed1(i,1)=grad_speed(i,2);
    grad_speed1(i,w)=grad_speed(i,w-1);
end

for j=1:w
    grad_speed1(1,j)=grad_speed(2,j);
    grad_speed1(h,j)=grad_speed(h-1,j);
end

end

