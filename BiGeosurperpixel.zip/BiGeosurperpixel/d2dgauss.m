function h = d2dgauss(n1,sigma1,n2,sigma2,theta)
% This function returns a 2D edge detector (first order derivative
% of 2D Gaussian function) with size n1*n2; theta is the angle that
% the detector rotated counter clockwise; and sigma1 and sigma2 are the
% standard deviation of the Gaussian functions.
r=[cos(theta) -sin(theta);
   sin(theta)  cos(theta)];
for i = 1 : n2 
    for j = 1 : n1
        u = r * [j-(n1+1)/2 i-(n2+1)/2]';
        h(i,j) = gaussian(u(1),sigma1)*dgaussian(u(2),sigma2);
    end
end
h = h / sqrt(sum(sum(abs(h).*abs(h))));


function y = gaussian(x,std)
%fun��o gaussiana:
y = exp(-x^2/(2*std^2)) / (std*sqrt(2*pi));

function y = dgaussian(x,std)
%Derivada de primeira ordem da fun��o gaussiana:
y = -x * gaussian(x,std) / std^2;

