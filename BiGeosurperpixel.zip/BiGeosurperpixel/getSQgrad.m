function [ sgradient ] = getSQgrad( imggrad,curseed,interval )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
height=size(imggrad,1);
width=size(imggrad,2);
 x1=fix(max(1,(curseed(2,1)-sqrt(3.0)/2*interval)));   
 x2=fix(min(double(curseed(2,1)+sqrt(3.0)/2*interval),(width)));
 y1=fix(max(1,(curseed(1,1)-interval)));
 y2=fix(min(double(curseed(1,1)+interval),(height)));
 sgradient=0.0;
for i=y1:y2
     for j=x1:x2
         sgradient=sgradient+imggrad(i,j);
     end
 end

end

