
#include "mex.h"

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
{
     double *Edis,*Q,*W,*oldSeed;
     double *Dg,*nseeds;
     int n;
     int iWidth, iHeight;
     iHeight = mxGetM(prhs[0]);
     iWidth = mxGetN(prhs[0]);
     W=mxGetPr(prhs[0]);
     Dg=mxGetPr(prhs[1]);
     Edis=mxGetPr(prhs[2]);
     Q=mxGetPr(prhs[3]);
     oldSeed=mxGetPr(prhs[5]);
     nseeds=mxGetPr(prhs[4]);
     n=(int)nseeds[0];
    double *allx;
     double *ally;
     double *allw;
     plhs[0] =  mxCreateDoubleMatrix(2,n, mxREAL);
     plhs[1]=   mxCreateDoubleMatrix(1,n, mxREAL);
     plhs[2]=   mxCreateDoubleMatrix(1,n, mxREAL);
     plhs[3]=   mxCreateDoubleMatrix(1,n, mxREAL);
     allx= mxGetPr(plhs[1]);
     ally=mxGetPr(plhs[2]);
     allw=mxGetPr(plhs[3]);
     double *newseed=mxGetPr(plhs[0]);
     for(int i=0;i<n;i++)
     {
         allx[i]=0.0;
         ally[i]=0.0;
         allw[i]=0.0;
         newseed[i*2]  = oldSeed[i*2];
         newseed[i*2+1]= oldSeed[i*2+1]; 
     }
     for(int i=0;i<iWidth;i++)
     {
         for(int j=0;j<iHeight;j++)
         {
             if(Edis[i*iHeight+j]>1E-8)
             {
             int num=(int)Q[i*iHeight+j];
             num=num-1;
             allx[num]=allx[num]+(W[i*iHeight+j]*Dg[i*iHeight+j]*(i+1)/Edis[i*iHeight+j]);
             ally[num]=ally[num]+(W[i*iHeight+j]*Dg[i*iHeight+j]*(j+1)/Edis[i*iHeight+j]);
             allw[num]=allw[num]+(W[i*iHeight+j]*Dg[i*iHeight+j]/Edis[i*iHeight+j]);
             }
         }
     }
     for(int i=0;i<n;i++)
     {
         int x,y;
         if(allw[i]>1E-5)
         {
         y=ally[i]/allw[i];
         x=allx[i]/allw[i];
         }
         if(x>=1&&x<=iWidth)
         {
         newseed[i*2+1]=x;
         }
         else if(x<1&&x>-15) newseed[i*2+1]= 1;
         else if(x>iHeight&&x<iHeight+15) newseed[i*2+1]=iWidth;
         if(y>=1&&y<=iHeight)
         {
         newseed[i*2]= y;
         }
         else if(y<1&&y>-15) newseed[i*2]= 1;
         else if(y>iHeight&&y<iHeight+15) newseed[i*2]= iHeight;
     }
}
