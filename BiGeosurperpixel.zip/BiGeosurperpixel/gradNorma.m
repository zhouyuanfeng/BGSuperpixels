function [ Dist1 ] = gradNorma( Dist,L,gradmag )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
h=size(Dist,1);
w=size(Dist,2);
Dist1=zeros(h,w);
for i=1:h
    for j=1:w
        nn=L(i,j);
        jj=fix((nn-1)/h)+1;
        ii=mod((nn-1),h)+1;
        Dist1(i,j)=Dist(i,j)*gradmag(ii,jj);
    end
end

end

