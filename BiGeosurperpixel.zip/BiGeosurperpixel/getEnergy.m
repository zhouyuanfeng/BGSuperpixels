function [ Eng ] = getEnergy( W,D,WC )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
c=size(D);
h=c(1);
w=c(2);
%W=exp(-D./0.5);
Eng=0;
Eng2=0;
Enge=zeros(h,w);
for i=1:h
    for j=1:w
         t=(W(i,j)*D(i,j)*D(i,j));
%         t=W(i,j)*D(i,j);
        if(~isnan(t))
            Eng=Eng+t;
        else
            i
            j
        end
    end
end
for i=1:h
    for j=1:w
        Eng2=Eng2+Enge(i,j);
    end
end
end 

