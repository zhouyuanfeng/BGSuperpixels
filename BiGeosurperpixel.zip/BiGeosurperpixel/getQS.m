function [ CO ,QSd] = getQS( AS,LS,Isize )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
ns=size(AS,2);
CO=0;
QSd=zeros(1,ns);
for i=1:ns
    if(LS(1,i)~=0)
    Qs=4*pi*(AS(1,i)-(LS(1,i)/2))/(LS(1,i)*LS(1,i));
    if(Qs>1)
        QSd(1,i)=1;
    end
    CO=CO+Qs*AS(1,i)/Isize;
    end
end

end

