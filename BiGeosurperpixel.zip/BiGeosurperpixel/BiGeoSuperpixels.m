clear all;
clc;   
name2='8049';
[N,cmap]=imread([name2 '.jpg']);   
N = im2double(N);    
M2=N;  
N3=rgb2gray(N);   
N2=rgb2gray(N);
times=[];
num_all = [ 1024, 2163];
nlevel=1;
t1=clock; 
cannysig1=0.01;
cannysig2=0.06;  
thresh=[cannysig1,cannysig2];   
[BW1,gradmag]=cannyedge(N3,thresh); 
gradmag=rescale1(gradmag,0.03,0.06);     
 [Dist1,L]=bwdist(BW1,'euclidean');   
 Dist2=mat2gray(Dist1); 
 Dist3=exp(-Dist2/0.35);      
 minDist=min(min(Dist3));
 maxDist=max(max(Dist3));   
 Dist4=(maxDist-Dist3)/(maxDist-minDist);
 c=size(N);                                                   
 h=c(1);              
 w=c(2); 
 Needseeds=700;
numseed=Needseeds*1/2; 
sig=0.025;
v=0.3;
tav=2; 
lim=0.1;
alph=0.5; 
expSuperPixelDist = sqrt(prod(size(N2))/numseed);
   normSigma = floor(expSuperPixelDist / 2);   
[speed_grad, normGradMag] = get_speed_based_on_gradient(N2,[],normSigma,v);
 speed_grad=tunespeed(speed_grad);%��ͼ��߽紦�ٶ�΢��   
speedW=speed_grad;   
numthreshod=h*w/numseed*0.15;     
[seed_pos,seed_intv,avgrad]=getseedsIntial(N,numseed,normGradMag,Needseeds);
imgrad=1-speed_grad;  
seed_pos=getloclaMin(seed_pos,seed_intv,imgrad);
nseeds=size(seed_pos,2);
[ Wseed_color ] = get_seedhexavColor(seed_pos,N,seed_intv); 
Eng1=Inf;     
Eng2=0;             
derEng=Inf;                  
ite=1;     
 sucess=1;
 eng1=0; 
haEdist=1;
while((ite<=20&&derEng>2)||ite<10)
  M=M2;      
[D,DC,Q] = Compute_BiGeo_Distance(Dist4, seed_pos,N,Wseed_color,sig,lim,alph);

if(haEdist==1)
  W=exp(-DC.*DC/0.1); 
else 
    W=exp(-D.*D/0.1); 
end
 isQ=find(Q==0);
 if(isempty(isQ)==0)
     sucess=0
     break;
 end
 Edis=getEdisC2(seed_pos,Q);    
 EdisC=getEdisColor2(Wseed_color,Q,N);
[Wseed_color,seed_color sucess]=getavC(Q,nseeds,N,seed_pos,W,EdisC,D);
WeightC=getWeightCo1(N,seed_color,Q);
eng2=getEnergy(W,D,WeightC);   
derEng=abs(eng2-eng1);
eng1=eng2;
seed_pos1=seed_pos;
[seed_pos]=getNewSeedsbasdDSC(W,D,Edis,Q,nseeds,seed_pos);
seed_pos=round(seed_pos);
nseeds=size(seed_pos,2);   
ite=ite+1;
end
[D,DC,Q] = Compute_BiGeo_Distance(Dist4, seed_pos,N,Wseed_color,sig,lim,alph);
MO=ones(h,w);
 dx8 =[-1, -1,  0,  1, 1, 1, 0, -1]; 
 dy8 = [ 0, -1, -1, -1, 0, 1, 1,  1];
 dx4=[-1,0,1,0];
 dy4=[0,-1,0,1];
   for j=1:h
       for k=1:w
           np=0;
           for i=1:4
               x=k+dx4(1,i);
               y=j+dy4(1,i);
               if(x>0&&x<=w&&y>0&&y<=h)
               if(Q(j,k)<Q(y,x)&&MO(y,x)~=0)
                   np=np+1;
               end
               end
           end
           if(np>0)
               MO(j,k)=0;
               M(j,k,1)=1;
               M(j,k,2)=0;
               M(j,k,3)=0;
           end
       end
   end
   imshow(M);
clear D;
clear S;
clear Q;
clear DC;
clear MO;
clear M;  
clear N; 
clear BW;
clear Dist2;
% end
