#include "mex.h"
#include "math.h"
void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
{
    double *seeds;
   seeds=mxGetPr(prhs[0]);
   double *q;
   q=mxGetPr(prhs[1]);
   int iWidth, iHeight;
   iHeight = mxGetM(prhs[1]);
   iWidth = mxGetN(prhs[1]);
   double *Edis;
   plhs[0]= mxCreateDoubleMatrix(iHeight,iWidth, mxREAL);
   Edis=mxGetPr(plhs[0]);
   int num;
   int x,y;
   double dis;
   for(int i=0;i<iWidth;i++)
   {
       for(int j=0;j<iHeight;j++)
       {
           num=(int)q[i*iHeight+j];
           num=num-1;
           y=seeds[num*2];
           x=seeds[num*2+1];
           dis=(i+1-x)*(i+1-x)+(j+1-y)*(j+1-y);
           Edis[i*iHeight+j]=sqrt(dis);
       }
   }
   
}
