function [ speed_c ] = getSpeed_basedColor( img,seed_color,Q)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
c=size(img);
h=c(1);
w=c(2);
speed_c=zeros(h,w);
for i=1:h
    for j=1:w
       n=Q(i,j);
        speed_c(i,j)=(img(i,j,1)-seed_color(1,n))*(img(i,j,1)-seed_color(1,n))...
        +(img(i,j,2)-seed_color(2,n))*(img(i,j,2)-seed_color(2,n))+(img(i,j,3)-seed_color(3,n))*(img(i,j,3)-seed_color(3,n));
    end
end
speed_c=sqrt(speed_c);
speed_c=exp(-speed_c/0.04);
end

