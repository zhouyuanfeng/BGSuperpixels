function [Wseed_color,seed_color,sucess] = getavC(Q,nums,img,seed_pos,speedW,EdisC,Dg)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
 
c=size(Q);
h=c(1);
w=c(2);
Wseed_color=zeros(3,nums);
seed_color=zeros(3,nums);
Wssize=zeros(1,nums);
ssize=zeros(1,nums);
sucess=1;
for i=1:h
    for j=1:w
        n=Q(i,j);
        if(n==0)
            sucess=0;
            return;
        end
        if(EdisC(i,j)<1E-6)
            EdisC(i,j)=1E-6;
        end
%         Wseed_color(1,n)=Wseed_color(1,n)+img(i,j,1)*Dg(i,j)*speedW(i,j)/EdisC(i,j);
%         Wseed_color(2,n)=Wseed_color(2,n)+img(i,j,2)*Dg(i,j)*speedW(i,j)/EdisC(i,j);
%         Wseed_color(3,n)=Wseed_color(3,n)+img(i,j,3)*Dg(i,j)*speedW(i,j)/EdisC(i,j);
%         Wssize(1,n)=Wssize(1,n)+Dg(i,j)*speedW(i,j)/EdisC(i,j);
        Wseed_color(1,n)=Wseed_color(1,n)+img(i,j,1)*speedW(i,j);
        Wseed_color(2,n)=Wseed_color(2,n)+img(i,j,2)*speedW(i,j);
        Wseed_color(3,n)=Wseed_color(3,n)+img(i,j,3)*speedW(i,j);
        Wssize(1,n)=Wssize(1,n)+speedW(i,j);

        seed_color(1,n)=seed_color(1,n)+img(i,j,1);
        seed_color(2,n)=seed_color(2,n)+img(i,j,2);
        seed_color(3,n)=seed_color(3,n)+img(i,j,3);
        ssize(1,n)=ssize(1,n)+1;
 
    end
end 
for i=1:nums
    if(Wssize(1,i)>1E-5)
    Wseed_color(1,i)=Wseed_color(1,i)/Wssize(1,i);
    Wseed_color(2,i)=Wseed_color(2,i)/Wssize(1,i);
    Wseed_color(3,i)=Wseed_color(3,i)/Wssize(1,i);
    else
    Wseed_color(1,i)=img(seed_pos(1,i),seed_pos(2,i),1);  
    Wseed_color(2,i)=img(seed_pos(1,i),seed_pos(2,i),2); 
    Wseed_color(3,i)=img(seed_pos(1,i),seed_pos(2,i),3); 
    end
    if(ssize(1,i)>1E-5)
        seed_color(1,i)=seed_color(1,i)/ssize(1,i);
        seed_color(2,i)=seed_color(2,i)/ssize(1,i);
        seed_color(3,i)=seed_color(3,i)/ssize(1,i);
    else
        seed_color(1,i)=img(seed_pos(1,i),seed_pos(2,i),1);
        seed_color(2,i)=img(seed_pos(1,i),seed_pos(2,i),2);
        seed_color(3,i)=img(seed_pos(1,i),seed_pos(2,i),3);
    end
end

end

