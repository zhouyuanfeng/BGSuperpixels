#include "mex.h"
#include "math.h"
void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
 {
        double *Edis,*q1,*img;
        double *seed_color;
        int iWidth, iHeight;
        iHeight = mxGetM(prhs[0]);
        iWidth = mxGetN(prhs[0]);
        plhs[0] = mxCreateDoubleMatrix(iHeight,iWidth, mxREAL);
        img = mxGetPr(prhs[0]);
        q1 = mxGetPr(prhs[1]);
        seed_color=mxGetPr(prhs[2]);
       int  nseeds=mxGetN(prhs[2]);
         Edis=mxGetPr(plhs[0]);
        int size=iHeight*iWidth;
     
       for(int i=0;i<iWidth;i++)
         {
             for(int j=0;j<iHeight;j++)
             {
                  double dis;
                  dis=0.0;
                   double r,g,b;
                   int num=(int)q1[i*iHeight+j];
                   num=num-1;
                   r=seed_color[(num)*3];
                   g=seed_color[(num)*3+1];
                   b=seed_color[(num)*3+2];
                   //dis=(i-x)*(i-x)+(j-y)*(j-y);
                   dis=(img[i*iHeight+j]-r)*(img[i*iHeight+j]-r)+(img[i*iHeight+j+size]-g)*(img[i*iHeight+j+size]-g)+(img[i*iHeight+j+size*2]-b)*(img[i*iHeight+j+size*2]-b);
                   
               Edis[i*iHeight+j]=sqrt(dis);
             }
           }              
   }

