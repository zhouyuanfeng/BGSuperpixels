function [seeds_pos,seed_interval,avgrad] = getseedsIntial(img,numseed,imggrad,Needseeds)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
c = size(img);
h=c(1);
w=c(2);
nump=h*w;
spixel_size=nump/numseed;
grid_interval_S = sqrt(2*sqrt(3.0)/9*spixel_size)+0.5;%�����α߳�
r_interval = 1.5*grid_interval_S + 0.5;%��ֱ
r_interval=fix(r_interval);
c_interval = sqrt(3.0)*grid_interval_S + 0.5;%ˮƽ
c_interval=fix(c_interval);
rstrips = fix(h/r_interval+1); 
cstrips = fix(w/c_interval+1);
r_off = fix((h - r_interval*(rstrips - 1))/2); 
c_off = fix((w - c_interval*(cstrips - 1))/2);
Cr_interval_S=fix(grid_interval_S+0.5)*2;
nseeds=0;
seed_gradient=[];
seed_interval=[];
seeds_pos=[];
avgrad=getAvG(imggrad,numseed)*1.5;
haveseed=zeros(h,w);
for i=0:rstrips-1
     seed_r = fix(r_off + i*r_interval+1) ;
     c_move=0;
     d=fix(i);
     t=mod(d,2);
     if(t~=0)
         c_move=c_interval/2;
     end
    for j=0:cstrips-1
       seed_c=fix(c_move+c_off+j*c_interval+1);
        if(seed_r>=h)
            seed_r=fix(h);
        end
        if(seed_c>=w)
            seed_c=fix(w);
        end
        curseed(1,1) = fix(seed_r);
        curseed(2,1) = fix(seed_c);
        haveseed(seed_r,seed_c)=1;
        seeds_pos=[seeds_pos curseed];
        sgradient=gethexgradient( imggrad,curseed,Cr_interval_S,avgrad );
        seed_gradient=[seed_gradient,sgradient];
         seed_interval=[seed_interval Cr_interval_S];
    end
end  
nseeds=size(seeds_pos,2);
while(nseeds<Needseeds) 
    ns=nseeds;
    k=findMaxgradien( seed_gradient ); 
    curseed=seeds_pos(:,k);
    cur_interval=seed_interval(1,k);
     x1=round(max(1,(curseed(2,1)-sqrt(3.0)/2*cur_interval)));   
     x2=round(min(double(curseed(2,1)+sqrt(3.0)/2*cur_interval),(w)));
     y1=round(max(1,(curseed(1,1)-cur_interval)));
     y2=round(min(double(curseed(1,1)+cur_interval),(h)));
     curseedch=zeros(2,6);
     Sgradient=zeros(1,6);
     ishad=zeros(1,6); 
     curseedch(2,1) =  fix(x1+1/4*(x2-x1));
     curseedch(1,1) =  fix(y1+3/8*(y2-y1));
     ishad(1,1)=WhetherhaveSeeds( curseedch(:,1),haveseed, cur_interval/4 );
     if(ishad(1,1)==0)
         Sgradient(1,1)=gethexgradient(imggrad,curseedch(:,1),cur_interval/2,avgrad);
     else
         Sgradient(1,1)=0;
     end
      curseedch(2,2) = curseed(2,1);
      curseedch(1,2) = fix(y1+1/4*(y2-y1));
      ishad(1,2)=WhetherhaveSeeds( curseedch(:,2),haveseed, cur_interval/4 );
     if(ishad(1,2)==0)
         Sgradient(1,2)=gethexgradient(imggrad,curseedch(:,2),cur_interval/2,avgrad);
     else
         Sgradient(1,2)=0;
     end
     curseedch(2,3) = fix(x2-1/4*(x2-x1));
     curseedch(1,3) = fix(y1+3/8*(y2-y1));
     ishad(1,3)=WhetherhaveSeeds( curseedch(:,3),haveseed, cur_interval/4 );
     if(ishad(1,3)==0)
         Sgradient(1,3)=gethexgradient(imggrad,curseedch(:,3),cur_interval/2,avgrad);
     else
         Sgradient(1,3)=0;
     end
     curseedch(2,4) = fix(x1+1/4*(x2-x1));
     curseedch(1,4) = fix(y1+5/8*(y2-y1));
     ishad(1,4)=WhetherhaveSeeds( curseedch(:,4),haveseed, cur_interval/4 );
     if(ishad(1,4)==0)
         Sgradient(1,4)=gethexgradient(imggrad,curseedch(:,4),cur_interval/2,avgrad);
     else
         Sgradient(1,4)=0;
     end
     curseedch(2,5) = curseed(2,1);
     curseedch(1,5) = fix(y1+3/4*(y2-y1));
     ishad(1,5)=WhetherhaveSeeds( curseedch(:,5),haveseed, cur_interval/4 );
     if(ishad(1,5)==0)
         Sgradient(1,5)=gethexgradient(imggrad,curseedch(:,5),cur_interval/2,avgrad);
     else
         Sgradient(1,5)=0;
     end
     curseedch(2,6) = fix(x2-1/4*(x2-x1));
     curseedch(1,6) = fix(y1+5/8*(y2-y1));
     ishad(1,6)=WhetherhaveSeeds( curseedch(:,6),haveseed, cur_interval/4 );
     if(ishad(1,6)==0)
         Sgradient(1,6)=gethexgradient(imggrad,curseedch(:,6),cur_interval/2,avgrad);
     else
         Sgradient(1,6)=0;
     end
     maxSg=Sgradient(1,1);
     maxSk=1; 
     ishasall=1;
     %������С��������ѡ������ݶ���ֵ�����ظ�������һ��������
     for ii=1:6
         if(Sgradient(1,ii)>maxSg)
             maxSg=Sgradient(1,ii);
             maxSk=ii;
         end
     end
     if(maxSg==0)
         for ii=1:6
             if(ishad(1,ii)==0)
                 maxSk=ii;
                 ishasall=0;
                 break;
             end
         end
     else
         ishasall=0;
     end
     %�������С�����ζ������ˣ�������������α�ΪС������
     if(ishasall==1)
         seed_interval(1,k)=cur_interval/2;
         seed_gradient(1,k)=gethexgradient(imggrad,seeds_pos(:,k),cur_interval/2,avgrad);
         continue;
     end
     seeds_pos=[seeds_pos curseedch(:,maxSk)];
     %������������εı䳤С��2�������ڴ˲���
     if(cur_interval/2>2)
         seed_gradient=[seed_gradient Sgradient(maxSk)];
     else
         seed_gradient=[seed_gradient 0];
     end
     seed_interval=[seed_interval cur_interval/2];
     seed_gradient(1,k)=seed_gradient(1,k)-Sgradient(1,maxSk);
     haveseed(curseedch(1,maxSk),curseedch(2,maxSk))=1;
     ishad(1,maxSk)=1;
     isallhad=1;
     %�����������ӵ���Ѿ�ȫ��������
     for ii=1:6
         if(ishad(1,ii)==0)
             isallhad=0;
         end
     end
     if(isallhad==1)
         seed_interval(1,k)=cur_interval/2;
         seed_gradient(1,k)=gethexgradient(imggrad,seeds_pos(:,k),cur_interval/2,avgrad);
     end
     nseeds=size(seeds_pos,2);
end
seed_interval=seed_interval./2;
end

