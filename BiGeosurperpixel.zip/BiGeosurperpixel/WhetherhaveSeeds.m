function [ ishad ] = WhetherhaveSeeds( curseed,haseed,interval )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
ishad=0;
h=size(haseed,1);
w=size(haseed,2);
x1=fix(max(1,(curseed(2,1)-sqrt(3.0)/2*interval)));   
x2=fix(min(double(curseed(2,1)+sqrt(3.0)/2*interval),(w)));
y1=fix(max(1,(curseed(1,1)-interval)));
y2=fix(min(double(curseed(1,1)+interval),(h)));
for i=y1:y2
    for j=x1:x2
        if(haseed(i,j)==1)
            ishad=1;
            break;
        end
    end
end
end

