function [ seed_pos ] = getnewseeds_based_on_gradient( nseeds,mgradient,Q )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
seed_gra=zeros(1,nseeds);
seed_gra=Inf;
for i=1:nseeds
    seed_gra(1,i)=Inf;
end
h=size(Q,1);
w=size(Q,2);
seed_pos=zeros(2,nseeds);
for i=2:h-1
    for j=2:w-1
        if(mgradient(i,j)<seed_gra(1,Q(i,j)))
            seed_pos(1,Q(i,j))=i;
            seed_pos(2,Q(i,j))=j;
            seed_gra(1,Q(i,j))=mgradient(i,j);
        end
    end

end

