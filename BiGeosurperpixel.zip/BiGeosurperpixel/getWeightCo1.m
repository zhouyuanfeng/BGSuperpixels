function [ WeightC ] = getWeightCo1(img,seed_color,Q )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
h=size(img,1);
w=size(img,2);
WeightC=zeros(h,w);
for i=1:h
    for j=1:w
        n=Q(i,j);
        derI=(img(i,j,1)-seed_color(1,n))*(img(i,j,1)-seed_color(1,n))+(img(i,j,2)-seed_color(2,n))*(img(i,j,2)-seed_color(2,n))+(img(i,j,3)-seed_color(3,n))*(img(i,j,3)-seed_color(3,n));
        WeightC(i,j)=exp(-derI);
    end
end

end