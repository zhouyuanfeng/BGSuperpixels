#include "mex.h"

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
{
    double *phi,*q1,*al,*dx;
     int iWidth, iHeight;
     iHeight = mxGetM(prhs[0]);
     iWidth = mxGetN(prhs[0]);
      plhs[0] = mxCreateDoubleMatrix(iHeight,iWidth, mxREAL);
      phi = mxGetPr(prhs[0]);
      q1 = mxGetPr(prhs[1]);
      dx = mxGetPr(prhs[2]);
      int i,j,i1,j1;
      double d1,q2;
      al=mxGetPr(plhs[0]);
      for(i=0;i<iWidth;i++)
      {
          for(j=0;j<iHeight;j++)
          {
              al[i*iHeight+j]=0.0;
              }
          }
      for(i=0;i<iWidth;i++)
      {
          for(j=0;j<iHeight;j++)
          {
              d1=phi[i*iHeight+j];
              q2=q1[i*iHeight+j];
              for(i1=0;i1<iWidth;i1++)
              {
                  for(j1=0;j1<iHeight;j1++)
                  {
                      if(q1[i1*iHeight+j1]==q2)
                      {
                          if(phi[i1*iHeight+j1]<d1)
                          {
                              al[i*iHeight+j]=al[i*iHeight+j]+dx[i1*iHeight+j1];
                              }
                          }
                      }
               }
           }
       }
}
