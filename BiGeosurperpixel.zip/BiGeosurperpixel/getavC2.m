function [WCseed_color] = getavC2(Q,nums,img,seed_pos,speedW)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
c=size(Q);
h=c(1);
w=c(2);
WCseed_color=zeros(3,nums);
WCssize=zeros(1,nums);
for i=1:h
    for j=1:w
        n=Q(i,j);
        if(n==0)
            i
            j
        end
        WCseed_color(1,n)=WCseed_color(1,n)+img(i,j,1)*speedW(i,j);
        WCseed_color(2,n)=WCseed_color(2,n)+img(i,j,2)*speedW(i,j);
        WCseed_color(3,n)=WCseed_color(3,n)+img(i,j,3)*speedW(i,j);
        WCssize(1,n)=WCssize(1,n)+speedW(i,j);
    end
end 
for i=1:nums
    if(WCssize(1,i)>1E-5)
    WCseed_color(1,i)=WCseed_color(1,i)/WCssize(1,i);
    WCseed_color(2,i)=WCseed_color(2,i)/WCssize(1,i);
    WCseed_color(3,i)=WCseed_color(3,i)/WCssize(1,i);
    else
    WCseed_color(1,i)=img(seed_pos(1,i),seed_pos(2,i),1);  
    WCseed_color(2,i)=img(seed_pos(1,i),seed_pos(2,i),2); 
    WCseed_color(3,i)=img(seed_pos(1,i),seed_pos(2,i),3); 
    end
end

end

