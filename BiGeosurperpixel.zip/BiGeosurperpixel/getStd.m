function [ std ] = getStd( img )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
avR=0.0;
avG=0.0;
avB=0.0;
h=size(img,1);
w=size(img,2);
sizei=h*w;
for i=1:h
    for j=1:w
        avR=avR+img(i,j,1);
        avG=avG+img(i,j,2);
        avB=avB+img(i,j,3);
    end
end
avR=avR/sizei;
avG=avG/sizei;
avB=avB/sizei;
stdR=0;
stdG=0;
stdB=0;
for i=1:h
    for j=1:w
        stdR=stdR+(img(i,j,1)-avR)*(img(i,j,1)-avR);
        stdG=stdG+(img(i,j,2)-avG)*(img(i,j,2)-avG);
        stdB=stdB+(img(i,j,3)-avB)*(img(i,j,3)-avB);
    end
end
stdR=sqrt(1/sizei*stdR);
stdG=sqrt(1/sizei*stdG);
stdB=sqrt(1/sizei*stdB);
std= stdR*0.299 + stdG*0.587 + stdB*0.114

end

