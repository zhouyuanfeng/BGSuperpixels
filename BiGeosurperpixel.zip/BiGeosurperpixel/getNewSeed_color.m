function [ seed_color ] = getNewSeed_color(seed_pos,img )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
nseeds=size(seed_pos,2);
seed_color=zeros(3,nseeds);
h=size(img,1);
w=size(img,2);
for i=1:nseeds
    x=seed_pos(1,i);
    y=seed_pos(2,i);
    RsumC=0;
    GsumC=0;
    BsumC=0;
    count=0; 

    for ii=-1:1:1
        for jj=-1:1:1
            xii=x+ii;
            yjj=y+jj;
            if(xii>0&&xii<=h&&yjj>0&&yjj<=w)
                RsumC=RsumC+img(xii,yjj,1);
                GsumC=GsumC+img(xii,yjj,2);
                BsumC=BsumC+img(xii,yjj,3);
                count=count+1;
            end
        end
    end
    seed_color(1,i)=RsumC/count;
    seed_color(2,i)=GsumC/count;
    seed_color(3,i)=BsumC/count;
end
end

