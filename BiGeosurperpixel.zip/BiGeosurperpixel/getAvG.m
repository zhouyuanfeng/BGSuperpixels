function [ avgrad ] = getAvG( imggrad,nseeds )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
h=size(imggrad,1);
w=size(imggrad,2);
avgrad=0;
for i=1:h
    for j=1:w
        avgrad=avgrad+imggrad(i,j);
    end
end
avgrad=avgrad/(h*w);
end

