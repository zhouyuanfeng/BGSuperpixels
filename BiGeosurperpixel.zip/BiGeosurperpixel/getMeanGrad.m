function [ meangrad ] =getMeanGrad( imggrad )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
h=size(imggrad,1);
w=size(imggrad,2);


end

