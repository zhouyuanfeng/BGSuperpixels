function [nseeds,add_seed0,add_color,success] = Splitting( D,Q,avC ,img,numseeds,avCall,Nseeds,Hist)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
c=size(D);
h=c(1);
w=c(2);
nseeds=numseeds;
S1=ones(1,nseeds);
std=zeros(1,nseeds);
S=zeros(2,w*10,nseeds);
add_seed0=[];
add_color=[];
success=1;
stdall=0;
%isspilit=zeros(1,2*nseeds);
for i=1:h
    for j=1:w
        n=Q(i,j);
        AA(1,1)=i;
        AA(1,2)=j;
        S(:,S1(1,n),n)=AA;
        std(1,n)=std(1,n)+((img(i,j,1)-avC(1,n))*(img(i,j,1)-avC(1,n))+(img(i,j,2)-avC(2,n))*(img(i,j,2)-avC(2,n))+(img(i,j,3)-avC(3,n))*(img(i,j,3)-avC(3,n)))/3.0;   
        stdall=stdall+(img(i,j,1)-avCall)*(img(i,j,1)-avCall);
        S1(1,n)=S1(1,n)+1;
    end
end
S1=S1-1;
std=sqrt((std)./S1);
std=std*20;
stdall=sqrt(stdall/(h*w));
Tsd=stdall/(0.015*numseeds);
Tsd=Tsd/2;
%std=std*36;
for i=1:numseeds
    if(S1(1,i)>2)
    if(std(1,i)>1)
    nsupsize=S1(1,i);
    shist=zeros(2, nsupsize,64);%��¼�����ص�ֱ��ͼ������ÿһ���е�ÿ�����ص�λ��
    chist=zeros(1,64);%ֱ��ͼ
    Data=ones(2, nsupsize);
    for jj=1: nsupsize
    Data(:,jj)=fix(S(:,jj,i));%������i�е�����
    x=Data(1,jj);
    y=Data(2,jj);
    l=img(x,y,1);
    a=img(x,y,2);
    b=img(x,y,3);
    for j=1:4
        if(l<=Hist(1,j))
            ln=j;
            break;
        end
    end
    for j=1:4
        if(a<=Hist(2,j))
            la=j;
            break;
        end
    end
    for j=1:4
        if(b<=Hist(3,j))
            lb=j;
            break;
        end
    end
    %����ֱ��ͼ����ֵ��������˳����ص�ֱ��ͼ��
    nhist=(ln-1)+(la-1)*4+(lb-1)*4*4+1;
    chist(1,nhist)=chist(1,nhist)+1;
    shist(:,chist(1,nhist),nhist)= Data(:,jj);
    end
    plot(chist);
    %�ҳ�ֱ��ͼ����������
    max1=0;
    maxi1=0;
    maxi2=0;
    max2=0;
    for ii=1:64
        if(chist(1,ii)>max1)
            max2=max1;
            maxi2=maxi1;
            max1=chist(1,ii);
            maxi1=ii;
        else
            if(chist(1,ii)>max2)
                max2=chist(1,ii)
                maxi2=ii;
            end
        end
    end
    if(abs(maxi1-maxi2)<2)
        continue;
    end
    if(maxi1~=maxi2&&max2~=0&&max1~=0)
    avl1=0;
    ava1=0;
    avb1=0;
    avl2=0;
    ava2=0;
    avb2=0;
    avx1=0;
    avy1=0;
    avx2=0;
    avy2=0;
    for ii=1:max1
        avx1=shist(1,ii,maxi1)+avx1;
        avy1=shist(2,ii,maxi1)+avy1;
    end
     for ii=1:max2
        avx2=shist(1,ii,maxi2)+avx2;
        avy2=shist(2,ii,maxi2)+avy2;
    end
    avx1=avx1/max1;
    avy1=avy1/max1;
    avx2=avx2/max2;
    avy2=avy2/max2;
    for ii=1:max1
        avl1=avl1+img(shist(1,ii,maxi1),shist(2,ii,maxi1),1);
        ava1=ava1+img(shist(1,ii,maxi1),shist(2,ii,maxi1),2);
        avb1=avb1+img(shist(1,ii,maxi1),shist(2,ii,maxi1),3);
    end
     for ii=1:max2
        avl2=avl2+img(shist(1,ii,maxi2),shist(2,ii,maxi2),1);
        ava2=ava2+img(shist(1,ii,maxi2),shist(2,ii,maxi2),2);
        avb2=avb2+img(shist(1,ii,maxi2),shist(2,ii,maxi2),3);
     end
   %����
   avl1=avl1/max1;
   ava1=ava1/max1;
   avb1=avb1/max1;
   avl2=avl2/max2;
   ava2=ava2/max2;
   avb2=avb2/max2;
%    derI1x=0;
%    derI1y=0
%    derI2x=0;
%    derI2y=0;
%    derI1=0;
%    derI2=0;
%    for ii=1:nsupsize
%        x=Data(1,ii);
%        y=Data(2,ii);
%        sw1=(img(x,y,1)-avl1)*(img(x,y,1)-avl1)+(img(x,y,2)-ava1)*(img(x,y,2)-ava1)+(img(x,y,3)-avb1)*(img(x,y,3)-avb1);
%        sw2=(img(x,y,1)-avl2)*(img(x,y,1)-avl2)+(img(x,y,2)-ava2)*(img(x,y,2)-ava2)+(img(x,y,3)-avb2)*(img(x,y,3)-avb2);
%        
%        derI1x=derI1x+1.0/(sw1+0.1)*x;
%        derI1y=derI1y+1.0/(sw1+0.1)*y;
%        derI2x=derI2x+1.0/(sw2+0.1)*x;
%        derI2y=derI2y+1.0/(sw2+0.1)*y;
%        derI1=derI1+1.0/(sw1+0.1);
%        derI2=derI2+1.0/(sw2+0.1);
%    end
    if(abs(avx1-avx2)<3&&abs(avy1-avy2)<3)
        continue;
    end
    add_seed1(1,1)=fix(avx1);
    add_seed1(2,1)=fix(avy1);
    add_seed1(3,1)=i;
    add_seed2(1,1)=fix(avx2);
    add_seed2(2,1)=fix(avy2);
     nseeds=nseeds+1;
    add_seed2(3,1)=nseeds;
    add_seed0=[add_seed0,add_seed1];
    add_seed0=[add_seed0,add_seed2];
    add_color1(1,1)=avl1;
    add_color1(2,1)=ava1;
    add_color1(3,1)=avb1;
    add_color2(1,1)=avl2;
    add_color2(2,1)=ava2;
    add_color2(3,1)=avb2;
    add_color=[add_color add_color1];
    add_color=[add_color,add_color2];
    end
    end
    end
    clear  chist;
    clear shist;
    clear Data;
end 
end


