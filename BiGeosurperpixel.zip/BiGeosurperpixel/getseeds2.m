function [seeds,seed_color,seed_intv,numseeds,avgrad] = getseeds2(img,numseed,imggrad,tav,numthreshod)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
c = size(img);
h=c(1);
w=c(2);
nump=h*w;
spixel_size=nump/numseed;
grid_interval_S = sqrt(2*sqrt(3.0)/9*spixel_size)+0.5;
r_interval = 1.5*grid_interval_S + 0.5;
r_interval=fix(r_interval);
c_interval = sqrt(3.0)*grid_interval_S + 0.5;
c_interval=fix(c_interval);
rstrips = fix(h/r_interval+1); 
cstrips = fix(w/c_interval+1);
r_off = fix((h - r_interval*(rstrips - 1))/2); 
c_off = fix((w - c_interval*(cstrips - 1))/2);
seeds1=[];
seed_intv=[];
numseeds1=0;
seed_color1=[];
avgrad=getAvG(imggrad,numseed)*tav;
haveseed=zeros(h,w);
%avgrad=Inf;  
%avgrad=getStd(img)*1;
for i=0:rstrips-1
     seed_r = fix(r_off + i*r_interval+1) ;
     c_move=0;
     d=fix(i);
     t=mod(d,2);
     if(t~=0)
         c_move=c_interval/2;
     end
    for j=0:cstrips-1
       seed_c=fix(c_move+c_off+j*c_interval+1);
        if(seed_r>=h)
            seed_r=fix(h);
        end
        if(seed_c>=w)
            seed_c=fix(w);
        end
        curseed(1,1) = fix(seed_r);
        curseed(2,1) = fix(seed_c);
        seeds_pos=[];
        seed_color=[];
        seed_interval=[];
        nseeds=0;
       % haveseed(curseed(1,1),curseed(2,1))=1;
        [seeds_pos,nseeds,seed_color,haveseed,seed_interval]=hextree2(img, nseeds,imggrad,seeds_pos,curseed,seed_color,fix(grid_interval_S+0.5)*2,avgrad,haveseed,seed_interval,numthreshod);
        seeds1=[seeds1 seeds_pos];
        numseeds1=nseeds+numseeds1;
        seed_intv=[seed_intv,seed_interval];
        seed_color1=[seed_color1 seed_color];
        
    end
end
seeds=seeds1;
numseeds=numseeds1;
seed_color=seed_color1;
end

