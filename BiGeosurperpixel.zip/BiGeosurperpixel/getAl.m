function [ Al ] = getAl( D,Q )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
c=size(D);
h=c(1);
w=c(2);
Al=zeros(h,w);
for i=1:h
    for j=1:w
        d1=D(i,j);
        q1=Q(i,j);
        for i1=1:h
            for j1=1:w
                if(Q(i1,j1)==q1)
                    if(D(i1,j1)<d1)
                        Al(i,j)=Al(i,j)+D(i1,j1);
                    end
                end
            end
        end
    end
end
end

